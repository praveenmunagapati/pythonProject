import React from "react";

const CourseFeedback = () => {
	return (
		<div className="courses-details-desc-style-two">
			<div className="row justify-content-center">
				<h3>Course Feedback Coming Soon...</h3>
			</div>
		</div>
	);
};

export default CourseFeedback;
