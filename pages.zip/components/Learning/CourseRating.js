import React from "react";

const CourseRating = () => {
	return (
		<div className="courses-details-desc-style-two">
			<div className="row justify-content-center">
				<h3>Course Rating Coming Soon...</h3>
			</div>
		</div>
	);
};

export default CourseRating;
