// REDUX ACTION TYPES
export const ADD_TO_CART = "ADD_TO_CART";
export const REMOVE_CART = "REMOVE_CART";
export const RESET_CART = "RESET_CART";
export const GET_DISCOUNT = "GET_DISCOUNT";
