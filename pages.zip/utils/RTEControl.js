module.exports = [
	["bold", "italic", "underline"],
	["h1", "h2", "h3", "h4"],
	["link", "video"],
	["code", "sup", "sub"],
	["alignLeft", "alignCenter", "alignRight"],
];
