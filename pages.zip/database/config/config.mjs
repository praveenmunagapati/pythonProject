export default {
	development: {
		username: 'root',
		password: '123456',
		database: 'elearniv_dev',
		host: process.env.DB_HOSTNAME,
		port: process.env.DB_PORT,
		dialect: "mysql",
	},
	production: {
		username: 'root',
		password: '123456',
		database: 'elearniv_dev',
		host: process.env.DB_HOSTNAME,
		port: process.env.DB_PORT,
		dialect: "mysql",
	},
};
